/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.onthatilepart1;
import java.util.Scanner;


public class Login {
    String user;
    String pass;

    public boolean checkUserName(String username) {
        if (username.length() <= 5 && username.contains("_")) {
            return true;
        } else {
            return false;
        }
    }

    public boolean checkPasswordComplexity(String password) {
        boolean hasCap = false;
        boolean hasNum = false;
        boolean hasSpecial = false;

        if (password.length() < 8) {
            return false;
        }

        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isUpperCase(c)) {
                hasCap = true;
            }
            if (Character.isDigit(c)) {
                hasNum = true;
            }
            if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }

        if (hasCap && hasNum && hasSpecial) {
            return true;
        } else {
            return false;
        }
    }

    public boolean checkCellPhoneNumber(String cell) {
        if (cell.length() == 12 && cell.startsWith("+27")) {
            return true;
        } else {
            return false;
        }
    }

    public String registerUser(String username, String password, String cell) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cell)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        user = username;
        pass = password;
        return "User registered successfully";
    }

    public boolean loginUser(String username, String password) {
        if (username.equals(user) && password.equals(pass)) {
            return true;
        } else {
            return false;
        }
    }

    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + username + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
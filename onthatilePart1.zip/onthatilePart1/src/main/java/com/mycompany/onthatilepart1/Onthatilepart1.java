/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.onthatilepart1;
 import java.util.Scanner;
/**
 *
 * @author Student
 */


public class Onthatilepart1 {
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Login login = new Login();

        System.out.print("Enter username: ");
        String username = sc.nextLine();

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        System.out.print("Enter cell number: ");
        String cell = sc.nextLine();

        String result = login.registerUser(username, password, cell);
        System.out.println(result);

        if (result.equals("User registered successfully")) {
           System.out.print("Enter username: ");
            String loginU = sc.nextLine();

            System.out.print("Enter password: ");
            String loginP = sc.nextLine();

            System.out.println(login.returnLoginStatus(loginU, loginP));
        }
    }
}
    


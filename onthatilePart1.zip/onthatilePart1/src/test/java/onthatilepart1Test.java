/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 *//**
  
 *
 * @author Student
 */


public class onthatilepart1Test {
    public static void main(String[] args) {
        onthatilepart1Tes obj = new onthatilepart1Test();
        
        System.out.println("Username kyl_1: " + obj.checkUserName("kyl_1") + " (should be true)");
        System.out.println("Username kyle!!!!!!!: " + obj.checkUserName("kyle!!!!!!!") + " (should be false)");
        System.out.println("Password Ch&&sec@ke99!: " + obj.checkPasswordComplexity("Ch&&sec@ke99!") + " (should be true)");
        System.out.println("Password password: " + obj.checkPasswordComplexity("password") + " (should be false)");
        System.out.println("Cell +27831234567: " + obj.checkCellPhoneNumber("+27831234567") + " (should be true)");
        System.out.println("Cell 08966553: " + obj.checkCellPhoneNumber("08966553") + " (should be false)");
    }
}
